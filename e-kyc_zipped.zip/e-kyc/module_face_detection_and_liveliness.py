
import face_recognition
import pytesseract
from PIL import Image
import re


def compare_faces(image_path1, image_path2):

    image1 = face_recognition.load_image_file(image_path1)
    image2 = face_recognition.load_image_file(image_path2)

    encodings1 = face_recognition.face_encodings(image1)
    encodings2 = face_recognition.face_encodings(image2)

    if len(encodings1) == 0:
        raise ValueError(f"No faces found in the first image: {image_path1}")
    if len(encodings2) == 0:
        raise ValueError(f"No faces found in the second image: {image_path2}")

    match = face_recognition.compare_faces([encodings1[0]], encodings2[0])

    return match[0];




def extract_aadhaar_info(image_path):
    """
    Extracts information from an image of an Aadhaar card using OCR.

    :param image_path: Path to the image of the Aadhaar card.
    :return: Dictionary containing extracted information.
    """
    # Load the image using PIL
    image = Image.open(image_path)

    # Use pytesseract to perform OCR on the image
    ocr_result = pytesseract.image_to_string(image)

    # Use regular expressions to extract specific fields
    # Assuming the Aadhaar card contains the following fields
    # Name, Aadhaar Number, Date of Birth, Address

    aadhaar_info = {}

    # Extract Aadhaar number (usually a 12-digit number)
    aadhaar_number = re.search(r'\b\d{4}\s\d{4}\s\d{4}\b', ocr_result)
    if aadhaar_number:
        aadhaar_info['Aadhaar Number'] = aadhaar_number.group(0)

    # Extract Name (assuming it comes after the label "Name")
    name = re.search(r'Name\s*:\s*(.*)', ocr_result)
    if name:
        aadhaar_info['Name'] = name.group(1).strip()

    # Extract Date of Birth (DOB) (assuming it follows the format DD/MM/YYYY or similar)
    dob = re.search(r'DOB\s*:\s*(\d{2}/\d{2}/\d{4})', ocr_result)
    if dob:
        aadhaar_info['Date of Birth'] = dob.group(1).strip()

    # Extract Address (assuming it starts after the label "Address" and ends before the next label)
    address = re.search(r'Address\s*:\s*(.*)\n', ocr_result)
    if address:
        aadhaar_info['Address'] = address.group(1).strip()

    return aadhaar_info








# Example usage
image_path = './MyAadhar.jpeg'
info = extract_aadhaar_info(image_path)
if 'Aadhaar Number' not in info :
    print("Either the image in not clear or not valid!, Please try again");
else:
    print(info)



# image1_path = "./MyImg1.jpeg"
# image2_path = "./MyImg2.jpeg"
# image3_path = "./notMyImage.jpeg"
# result = compare_faces(image1_path, image3_path)
# result2 = compare_faces(image1_path, image2_path)

# print("The images match." if result else "The images do not match.")
# print("The images match." if result2 else "The images do not match.")